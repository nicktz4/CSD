public interface Automobile {

    public void startUp();

    public void openWindows();

    public void closeWindows();

    public void lock();

    public void unlock();
}
