/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mbaritak
 */
public enum CarModel {
    
    A1,S1,A3,S3,RS3,A4,S4,RS4,A5,S5,RS5;
    
}
